/*
 * Programming Quiz: All Tied Up (2-5)
 */

var joke = "Why couldn't the shoes go out and play? \nThey were all \"tied\" up!";
console.log(joke);
