/*
 * Programming Quiz: /*
 * Programming Quiz: Converting Tempatures (2-2)
 *
 * Use the Celsius-to-Fahrenheit formula to set the fahrenheit varible:
 *
 *     F = C x 1.8 + 32
 *
 * Log the fahrenheit variable to the console.
 *
 */

var celsius = 12;
var fahrenheit = (celsius * 1.8) + 32; /* convert celsius to fahrenheit here */

console.log(fahrenheit);
/* print out result here */ (2-2)
 *
 * Use the Celsius-to-Fahrenheit formula to set the fahrenheit varible:
 *
 *     F = C x 1.8 + 32
 *
 * Log the fahrenheit variable to the console.
 *
 */

var celsius = 12;
var fahrenheit = (celsius * 1.8) + 32; /* convert celsius to fahrenheit here */

console.log(fahrenheit);
/* print out result here */
