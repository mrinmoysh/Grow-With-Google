/*
 * Programming Quiz: Favorite Food (2-3)
 */

console.log("Double Mocha");
