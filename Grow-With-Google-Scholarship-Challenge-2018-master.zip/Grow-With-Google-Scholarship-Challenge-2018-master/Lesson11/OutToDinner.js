/*
 * Programming Quiz: Out to Dinner (2-10)
 */
var bill = 10.25 + 3.99 + 7.15; 
var tip = bill * .15; 
var total = bill + tip;
console.log(total.toFixed(2));
// your code goes here
