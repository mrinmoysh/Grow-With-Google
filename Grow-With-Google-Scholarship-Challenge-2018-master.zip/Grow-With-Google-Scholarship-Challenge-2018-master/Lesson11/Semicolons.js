
var thingOne = "red";
var thingTwo = "blue";
console.log(thingOne + " " + thingTwo);
