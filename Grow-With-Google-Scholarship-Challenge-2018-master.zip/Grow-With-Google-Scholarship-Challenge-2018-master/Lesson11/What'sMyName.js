/*
 * Programming Quiz: What's my Name? (2-9)
 */
var fullName = "Madison A. Estabrook";
// your code goes here
