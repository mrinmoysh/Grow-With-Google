/*
 * Programming Quiz: Yosa Buson (2-6)
 */

var haiku = "Blowing from the west" +  "\nFallen leaves gather" + "\nIn the east.";
console.log(haiku);
