/*
 * Programming Quiz: Changing the Loop (4-4)
 */

// rewrite the while loop as a for loop
for(var x = 9; x >= 1; x--) {
    console.log("hello " + x);
}
