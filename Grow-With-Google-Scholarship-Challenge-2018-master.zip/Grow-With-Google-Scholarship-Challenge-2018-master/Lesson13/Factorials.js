/*
 * Programming Quiz: Factorials (4-7)
 */
var solution = 1;
for(var x = 1; x <= 12; x++) {
    solution =  solution * x; 
}
console.log(solution);
