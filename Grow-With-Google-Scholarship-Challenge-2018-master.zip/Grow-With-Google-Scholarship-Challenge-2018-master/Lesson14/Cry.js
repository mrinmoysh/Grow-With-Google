var cry = function booHoo(){ 
    thing = "boohoo!" ; 
    return thing; 
}
console.log(cry()); 
