/*
 * Programming Quiz: Inline Functions (5-6)
 */

// don't change this code
function emotions(myString, myFunc) {
    console.log("I am " + myString + ", " + myFunc(2));
}
 var myString = "happy"; 
 var ha = "ha"; 
 for( var i = 0; i <=2 ; i++ ) {
     return emotions + "!"; 
 }
