/*
 * Programming Quiz: Laugh it Off 1 (5-1)
 */
function laugh() { 
 var ha = "hahahahahahahahahaha!" ; 
 return ha;
}
console.log(laugh());
