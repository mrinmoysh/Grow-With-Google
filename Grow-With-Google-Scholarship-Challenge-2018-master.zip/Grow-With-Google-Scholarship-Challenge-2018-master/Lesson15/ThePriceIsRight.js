/*
 * Programming Quiz: The Price is Right (6-3)
 */

var prices = [1.23, 48.11, 90.11, 8.50, 9.99, 1.00, 1.10, 67.00];
prices[0] = 3.14; 
prices[2] = 50.00; 
prices[6] = 1.00; 
console.log(prices);
