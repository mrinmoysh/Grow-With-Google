/*
 * Programming Quiz: UdaciFamily (6-1)
 */
udaciFamily = ["Julia", "James", "Madison"]; 
console.log(udaciFamily);
