/*
 * Programming Quiz: Menu Items (7-2)
 */

var breakfast = { 
   name: "The Lumberjack", 
   price: 9.95, 
   ingredients: ["eggs", "sausage", "toast", "hashbrowns", "pancakes"]
}; 
