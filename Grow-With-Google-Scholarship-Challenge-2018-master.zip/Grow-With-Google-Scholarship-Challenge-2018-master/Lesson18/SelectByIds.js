/*
For this quiz, use a jQuery class selector to grab all the element with id 'nav' on the page!
*/

// don't change this variable!
var nav;

nav = $('#nav');
