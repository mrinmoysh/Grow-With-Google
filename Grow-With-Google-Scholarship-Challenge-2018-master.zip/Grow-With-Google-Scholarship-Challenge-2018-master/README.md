# Grow With Google Scholarship Challenge 2018 #
_By *Madison Estabrook*_
## Introduction ##
I was lucky enough to be selected for [*Udacity's*](udacity.com) _Grow With Google Challenge Scholarship_. This repo covers lessons 1-22 in the [_Grow With Google challenge Scholarship course_](https://classroom.udacity.com/courses/ud304-gwg).
## Follow-Up Scholarship ##
I hope to be selected for the follow-up scholarship, which covers the full Nanodegree. I am doing my best to be selected for the follow-up scholarship. There is no seperate application; people are selected based on (in order of importantance): 
1. Completing the [course](https://classroom.udacity.com/courses/ud304-gwg)
2. Activity on the [forums](https://discussions.udacity.com/c/standalone-courses/ud304-gwg) 
3. Activity on [Slack](webbeg-googlescholar.slack.com) 
